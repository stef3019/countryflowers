<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 01/30/2018
 * Time: 3:59 PM
 */
if (!defined('ABSPATH')) {
    die('-1');
}
class WPBakeryShortCode_GSF_Process extends G5P_ShortCode_Base {

}